$(function() {

    $("#btnMakePrediction").click(function () {
        // alert("buton");
        //jQuery.support.cors = true;
        //$.ajax({
        //    //   url: 'http://mlwebservice.azurewebsites.net/api/IncomePrediction/GetPrediction/',
        //    url: 'api/IncomePrediction/GetPrediction/',
        //    type: "GET",
        //    data: {
        //        age: '53',
        //        workclass: 'Self-emp-not-inc',
        //        fnlwgt: '209642',
        //        education: 'HS-grad',
        //        educationnum: '9',
        //        maritalstatus: 'Married-civ-spouse',
        //        occupation: 'Exec-managerial',
        //        relationship: 'Husband',
        //        race: 'White',
        //        sex: 'Male',
        //        capitalgain: '0',
        //        capitalloss: '0',
        //        hoursperweek: '45',
        //        nativecountry: 'United-States',
        //    },
        //    dataType: "json"
        //    }).done(function (data) {
        //        alert(data);
        //        alert(data.toString());
        //       });


        var jqxhr = $.ajax(
            {
                url: 'http://mlwebservice.azurewebsites.net/api/IncomePrediction/GetPrediction',
                type: "GET",
                data: {
                    age: '53',
                    workclass: 'Self-emp-not-inc',
                    fnlwgt: '209642',
                    education: 'HS-grad',
                    educationnum: '9',
                    maritalstatus: 'Married-civ-spouse',
                    occupation: 'Exec-managerial',
                    relationship: 'Husband',
                    race: 'White',
                    sex: 'Male',
                    capitalgain: '0',
                    capitalloss: '0',
                    hoursperweek: '45',
                    nativecountry: 'United-States'
                },
                dataType: "json",
                async: false
            }
            )
         .done(function (responseData) {
             //  alert("success");
             $.each(responseData, function (index, item) {
                 //alert(index);
                 //alert(item);

                 // append the first and last name to the table
                 //#rightSide.append("<label>" + index + "</label>" + "<label>" + item + "</label>");

                 $("#rightSide").append("<label>" + index + "</label>" + "<label>" + item + "</label>");
             });

         })
         .fail(function () {
             //alert("jberror");
             $rightSide.append("<div>" + "jberror" + "</div>" +
                            "<div>" + "-bad" + "</div>");
         })
         .always(function () {
             alert("complete");
         });

        // Set another completion function for the request above
        jqxhr.always(function () {
            alert("second complete");
        });








        //}).error(function (jqXHR, textStatus, errorThrown) {
        //    alert(jqXHR.responseText);
        //});

    });
});
