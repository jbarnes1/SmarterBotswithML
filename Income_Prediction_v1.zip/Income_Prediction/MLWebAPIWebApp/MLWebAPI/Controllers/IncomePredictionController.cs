﻿using MLWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.IO;
using Newtonsoft.Json;

namespace MLWebAPI.Controllers
{
    // ALLOW *ALL* Cross-Origin Resource Sharing CORS Requests
    [EnableCors("*", "*", "*")]
    public class IncomePredictionController : ApiController
    {
        public class StringTable
        {
            public string[] ColumnNames { get; set; }
            public string[,] Values { get; set; }
        }
        public static string outMLResultData = "";

        [HttpGet]
        public async Task<IncomePredictionResults> GetPrediction()
        {
            //Prepare a new ML Response Data Structure for the results
            IncomePredictionResults incomePredResults = new IncomePredictionResults();

            //Parse the input parameters from the request
            NameValueCollection nvc = HttpUtility.ParseQueryString(Request.RequestUri.Query);

            //Validate Number of Input parameters (TODO: Add more validations)
            if (nvc.Count < 14) { }

            // Extract Input Values
            string inAge = nvc[0];
            string inWorkClass = nvc[1];
            string infnlwgt = nvc[2];
            string inEducation = nvc[3];
            string inEducationNum = nvc[4];
            string inMaritalStatus = nvc[5];
            string inOccupation = nvc[6];
            string inRelationship = nvc[7];
            string inRace = nvc[8];
            string inSex = nvc[9];
            string inCapitalGain = nvc[10];
            string inCapitalLoss = nvc[11];
            string inHoursPerWeek = nvc[12];
            string inNativeCountry = nvc[13];

            using (var client = new HttpClient())
            {
                var scoreRequest = new
                {
                    Inputs = new Dictionary<string, StringTable>() { 
                        { "input1", 
                            new StringTable() 
                            {   ColumnNames = new string[] {"age", "workclass", "fnlwgt", "education", "education-num", "marital-status", "occupation", "relationship", "race", "sex", "capital-gain", "capital-loss", "hours-per-week", "native-country", "income"},
                                //Populate Input Parameters with input values
                                Values = new string[,] {  {
                                                            inAge,
                                                            inWorkClass,
                                                            infnlwgt,
                                                            inEducation,
                                                            inEducationNum,
                                                            inMaritalStatus,
                                                            inOccupation,
                                                            inRelationship,
                                                            inRace,
                                                            inSex,
                                                            inCapitalGain,
                                                            inCapitalLoss,
                                                            inHoursPerWeek,
                                                            inNativeCountry,
                                                            "0"
                                                        }   
                                                    }
                                                }
                                            },
                                         },
                    GlobalParameters = new Dictionary<string, string>()
                    {
                    }
                };
                var sw = new Stopwatch();
                const string apiKey = "c/1r9fLud5KOjsqTDKCW3r3EJXZty60yqO6bS63FqiA+/blYvU1R0zMyLXcaKsMOSa3aCjlLbFCsTNoxxvbKnA==";

                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);
                client.BaseAddress = new Uri("https://ussouthcentral.services.azureml.net/workspaces/12e23496953e4285a7cc2d669c0cc1aa/services/cd5a06839b7b40d68f5d2ffa26867373/execute?api-version=2.0&details=true");

                //Time the ML Web Service Call
                sw.Start();
                HttpResponseMessage response = await client.PostAsJsonAsync("", scoreRequest).ConfigureAwait(false);
                sw.Stop();
                string elapsed = sw.Elapsed.TotalSeconds.ToString();

                //Check Staus of Azure ML Web Service Call
                if (response.IsSuccessStatusCode)
                {
                    //Read the HTTP response
                    string MLResp = await response.Content.ReadAsStringAsync();//.ConfigureAwait(false);

                    //Parse ML Web Service Response and return a populated IncomePredictionResults response record
                    incomePredResults = ParseMLResponse(MLResp);

                    //Update for ML Service Response Time
                    incomePredResults.MLResponseTime = elapsed;
                }
                else
                {
                    incomePredResults.MLPrediction = response.ReasonPhrase.ToString();
                }

                client.Dispose();
                //return Ok(incomePredResults);
                return incomePredResults;
            }
        }
        private static IncomePredictionResults ParseMLResponse(string result)
        {
            //var cleaned = result.Replace("\"", string.Empty);
            //cleaned = cleaned.Replace("[", string.Empty);
            //cleaned = cleaned.Replace("]", string.Empty);
            //string[] mlResultsArr = cleaned.Split(",".ToCharArray());

            var cleaned = result.Replace("\"", string.Empty);
            cleaned = cleaned.Replace("[", string.Empty);
            cleaned = cleaned.Replace("]", string.Empty);
            cleaned = cleaned.Replace("{", string.Empty);
            cleaned = cleaned.Replace("}", string.Empty);

            cleaned = cleaned.Replace("Values:", string.Empty);
            string[] mlResultsArr = cleaned.Split(",".ToCharArray());

            IncomePredictionResults incomePredResult = new IncomePredictionResults();
            for (int i = 35; i < mlResultsArr.Length; i++)
            {
                switch (i)
                {
                    case 35:
                        incomePredResult.Age = mlResultsArr[i].ToString(); break;
                    case 36:
                        incomePredResult.WorkClass = mlResultsArr[i].ToString(); break;
                    case 37:
                        incomePredResult.Fnlwgt = mlResultsArr[i].ToString(); break;
                    case 38:
                        incomePredResult.Education = mlResultsArr[i].ToString(); break;
                    case 39:
                        incomePredResult.EducationNum = mlResultsArr[i].ToString(); break;
                    case 40:
                        incomePredResult.MaritalStatus = mlResultsArr[i].ToString(); break;
                    case 41:
                        incomePredResult.Occupation = mlResultsArr[i].ToString(); break;
                    case 42:
                        incomePredResult.Relationship = mlResultsArr[i].ToString(); break;
                    case 43:
                        incomePredResult.Race = mlResultsArr[i].ToString(); break;
                    case 44:
                        incomePredResult.Sex = mlResultsArr[i].ToString(); break;
                    case 45:
                        incomePredResult.CapitalGain = mlResultsArr[i].ToString(); break;
                    case 46:
                        incomePredResult.CapitalLoss = mlResultsArr[i].ToString(); break;
                    case 47:
                        incomePredResult.HoursPerWeek = mlResultsArr[i].ToString(); break;
                    case 48:
                        incomePredResult.NativeCountry = mlResultsArr[i].ToString(); break;
                    case 50:
                        incomePredResult.MLPrediction = mlResultsArr[i].ToString(); break;
                    case 51:
                        incomePredResult.MLConfidence = mlResultsArr[i].ToString(); break;

                    default:
                        break;
                }
            }
            return incomePredResult;
        }

    }
}












