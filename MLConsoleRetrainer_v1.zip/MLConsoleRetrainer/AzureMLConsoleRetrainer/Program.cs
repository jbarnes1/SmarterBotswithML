﻿// This code requires the Nuget package Microsoft.AspNet.WebApi.Client to be installed.
// Instructions for doing this in Visual Studio:
// Tools -> Nuget Package Manager -> Package Manager Console
// Install-Package Microsoft.AspNet.WebApi.Client
//
// Also, add a reference to Microsoft.WindowsAzure.Storage.dll for reading from and writing to the Azure blob storage

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using System.Runtime.Serialization;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Auth;
using Microsoft.WindowsAzure.Storage.Blob;
using Newtonsoft.Json;

namespace AzureMLConsoleRetrainer
{
 
    public class AzureBlobDataReference
    {
        // Storage connection string used for regular blobs. It has the following format:
        // DefaultEndpointsProtocol=https;AccountName=ACCOUNT_NAME;AccountKey=ACCOUNT_KEY
        // It's not used for shared access signature blobs.
        public string ConnectionString { get; set; }

        // Relative uri for the blob, used for regular blobs as well as shared access 
        // signature blobs.
        public string RelativeLocation { get; set; }

        // Base url, only used for shared access signature blobs.
        public string BaseLocation { get; set; }

        // Shared access signature, only used for shared access signature blobs.
        public string SasBlobToken { get; set; }
    }

    public class ResourceLocation
    {
        public string Name { get; set; }

        public AzureBlobDataReference Location { get; set; }
    }

    public class ResourceLocations
    {
        public ResourceLocation[] Resources { get; set; }
    }
    public enum BatchScoreStatusCode
    {
        NotStarted,
        Running,
        Failed,
        Cancelled,
        Finished
    }
    public class BatchScoreStatus
    {
        // Status code for the batch scoring job
        public BatchScoreStatusCode StatusCode { get; set; }

        // Locations for the potential multiple batch scoring outputs
        public IDictionary<string, AzureBlobDataReference> Results { get; set; }

        // Error details, if any
        public string Details { get; set; }
    }

    public class BatchScoreRequest
    {
        public AzureBlobDataReference Input { get; set; }
        public IDictionary<string, string> GlobalParameters { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            InvokeBatchExecutionService().Wait();
        }

        static async Task WriteFailedResponse(HttpResponseMessage response)
        {
            Console.WriteLine(string.Format("The request failed with status code: {0}", response.StatusCode));

            // Print the headers - they include the requert ID and the timestamp, which are useful for debugging the failure
            Console.WriteLine(response.Headers.ToString());

            string responseContent = await response.Content.ReadAsStringAsync();
            Console.WriteLine(responseContent);
        }


        static void ProcessResults(BatchScoreStatus status)
        {

            foreach (var output in status.Results)
            {
                var blobLocation = output.Value;
                Console.WriteLine(string.Format("The result '{0}' is available at the following Azure Storage location:", output.Key));
                Console.WriteLine(string.Format("BaseLocation: {0}", blobLocation.BaseLocation));
                Console.WriteLine(string.Format("RelativeLocation: {0}", blobLocation.RelativeLocation));
                Console.WriteLine(string.Format("SasBlobToken: {0}", blobLocation.SasBlobToken));
                Console.WriteLine();

            }
        }

        // update scoring endpoint with retrained model
       // var updateResult = await scoringEndpoint.UpdateResource(new ResourceLocations() { Resources = new[] { new EndpointResource() { Name = Configurations.ScoringResourceName, Location = model } } });

        static async Task  UpdateModel(string inBaseLocation, string inRelativeLocation, string inSasBlobToken)
        {
            const string apiKey = "ABr2vQonVvhmxC9Em0CmVLhyP8BCNijwXZTcEE+kqZckNC6nMXuz8Vu04eOoVoYfgHA9UKZK8Cp0hRTKY68b5w=="; // Replace this with the API key for the default web service
            const string endpointUrl = "https://management.azureml.net/workspaces/12e23496953e4285a7cc2d669c0cc1aa/webservices/c15dace9f8594ac5a0a76d327836ec12/endpoints/retrained";
          
            var resourceLocations = new ResourceLocations()
            {
                Resources = new ResourceLocation[] {
                    new ResourceLocation()
                    {
                        Name = "Printer_Predict_Best_Action [trained model]",
                        Location = new AzureBlobDataReference()
                        {
                            // Replace these values with the ones that specify the location of the new value for this resource. For instance,
                            // if this resource is a trained model, you must first execute the training web service, using the Batch Execution API,
                            // to generate the new trained model. The location of the new trained model would be returned as the "Result" object
                            // in the response. 
                            BaseLocation=inBaseLocation,
                            RelativeLocation=inRelativeLocation,
                            SasBlobToken=inSasBlobToken
                        }
                    }
                }
            };

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue( "Bearer", apiKey);
                using (HttpRequestMessage request = new HttpRequestMessage(new HttpMethod("PATCH"), endpointUrl))
                {
                    request.Content = new StringContent(JsonConvert.SerializeObject(resourceLocations), System.Text.Encoding.UTF8, "application/json");
                    HttpResponseMessage response = await client.SendAsync(request);
                }
            }
        }

        static async Task InvokeBatchExecutionService()
        {
            // How this works:
            //
            // 1. Assume the input is present in a local file (if the web service accepts input)
            // 2. Upload the file to an Azure blob - you'd need an Azure storage account
            // 3. Call the Batch Execution Service to process the data in the blob. Any output is written to Azure blobs.
            // 4. Download the output blob, if any, to local file

            const string BaseUrl = "https://ussouthcentral.services.azureml.net/workspaces/12e23496953e4285a7cc2d669c0cc1aa/services/51664eb55e7948c2860df6e0eab25f94/jobs";

            const string StorageAccountName = "jbprinterhelpbotstorage"; // Replace this with your Azure Storage Account name
            const string StorageAccountKey = "KSIVRTFmBlnOTgvxFpjTOD6G7+/vXo0fEhG/vVHN392ShDDqoxU8aXQdWngCIn5ekoLNZpEpIo/W17LOq2s/4A=="; // Replace this with your Azure Storage Key
            const string StorageContainerName = "retrainingdatain"; // Replace this with your Azure Storage Container name

            //Update Data File below with version of training Data (1 or 2) 
            //AML_Printer_Issue_Best_Action_Data_v1_TAB.csv
            //AML_Printer_Issue_Best_Action_Data_v2_TAB.csv
            //AML_Printer_Issue_Best_Action_Data_RETRAINING_v2_TAB.csv
            
            const string InputFileLocation = "C:\\a_NCSU_Data\\FY18\\Code_Camp\\Demos\\AML_Printer_Issue_Best_Action_Data_v2_TAB.csv"; // Replace this with the location of your input file

            const string InputBlobName = "AML_Printer_Issue_Best_Action_Data.csv"; // Replace this with the name you would like to use for your Azure blob; this needs to have the same extension as the input file 

            const string apiKey = "lQChYaHanF+L8Xjf5GXLqlDnevD2bwcZA+z+KZ2bDNS4vBwgdJqdfrM5ipwL9Lv2ArZW8y4tlPkXJVB7sXi7gw=="; // Replace this with the API key for the web service


            // Make sure the file exists
            if (!File.Exists(InputFileLocation))
            {
                throw new FileNotFoundException(
                    string.Format(
                        CultureInfo.InvariantCulture,
                        "File {0} doesn't exist on local computer.",
                        InputFileLocation));
            }

            Console.WriteLine("Uploading the input to blob storage...");

            string storageConnectionString = string.Format("DefaultEndpointsProtocol=https;AccountName={0};AccountKey={1}", StorageAccountName, StorageAccountKey);
            var blobClient = CloudStorageAccount.Parse(storageConnectionString).CreateCloudBlobClient();
            var container = blobClient.GetContainerReference(StorageContainerName);
            container.CreateIfNotExists();
            var blob = container.GetBlockBlobReference(InputBlobName);
            blob.UploadFromFile(InputFileLocation, FileMode.Open);

            // set a time out for polling status
            const int TimeOutInMilliseconds = 120 * 1000; // Set a timeout of 2 minutes

            using (HttpClient client = new HttpClient())
            {
                BatchScoreRequest request = new BatchScoreRequest()
                {

                    Input = new AzureBlobDataReference()
                    {
                        ConnectionString = storageConnectionString,
                        RelativeLocation = blob.Uri.LocalPath
                    },
                    GlobalParameters = new Dictionary<string, string>()
                    {
                    }
                };

                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);

                // WARNING: The 'await' statement below can result in a deadlock if you are calling this code from the UI thread of an ASP.Net application.
                // One way to address this would be to call ConfigureAwait(false) so that the execution does not attempt to resume on the original context.
                // For instance, replace code such as:
                //      result = await DoSomeTask()
                // with the following:
                //      result = await DoSomeTask().ConfigureAwait(false)


                Console.WriteLine("Submitting the job...");

                // submit the job
                var response = await client.PostAsJsonAsync(BaseUrl + "?api-version=2.0", request);
                if (!response.IsSuccessStatusCode)
                {
                    await WriteFailedResponse(response);
                    return;
                }

                string jobId = await response.Content.ReadAsAsync<string>();
                Console.WriteLine(string.Format("Job ID: {0}", jobId));


                // start the job
                Console.WriteLine("Starting the job...");
                response = await client.PostAsync(BaseUrl + "/" + jobId + "/start?api-version=2.0", null);
                if (!response.IsSuccessStatusCode)
                {
                    await WriteFailedResponse(response);
                    return;
                }

                string jobLocation = BaseUrl + "/" + jobId + "?api-version=2.0";
                Stopwatch watch = Stopwatch.StartNew();
                bool done = false;
                while (!done)
                {
                    Console.WriteLine("Checking the job status...");
                    response = await client.GetAsync(jobLocation);
                    if (!response.IsSuccessStatusCode)
                    {
                        await WriteFailedResponse(response);
                        return;
                    }

                    BatchScoreStatus status = await response.Content.ReadAsAsync<BatchScoreStatus>();
                    if (watch.ElapsedMilliseconds > TimeOutInMilliseconds)
                    {
                        done = true;
                        Console.WriteLine(string.Format("Timed out. Deleting job {0} ...", jobId));
                        await client.DeleteAsync(jobLocation);
                    }
                    switch (status.StatusCode)
                    {
                        case BatchScoreStatusCode.NotStarted:
                            Console.WriteLine(string.Format("Job {0} not yet started...", jobId));
                            break;
                        case BatchScoreStatusCode.Running:
                            Console.WriteLine(string.Format("Job {0} running...", jobId));
                            break;
                        case BatchScoreStatusCode.Failed:
                            Console.WriteLine(string.Format("Job {0} failed!", jobId));
                            Console.WriteLine(string.Format("Error details: {0}", status.Details));
                            done = true;
                            break;
                        case BatchScoreStatusCode.Cancelled:
                            Console.WriteLine(string.Format("Job {0} cancelled!", jobId));
                            done = true;
                            break;
                        case BatchScoreStatusCode.Finished:
                            done = true;
                            Console.WriteLine(string.Format("Job {0} finished!", jobId));

                            ProcessResults(status);


                            foreach (var output in status.Results)
                            {
                                var blobLocation = output.Value;

                                if (output.Key == "output1")
                                {
                                    string inBaseLocation = blobLocation.BaseLocation.ToString();
                                    string inRelativeLocation = blobLocation.RelativeLocation.ToString();
                                    string inSasBlobToken = blobLocation.SasBlobToken.ToString();

                                    await UpdateModel(inBaseLocation, inRelativeLocation, inSasBlobToken);                                
                                }
 

                            }




                            break;
                    }

                    if (!done)
                    {
                        Thread.Sleep(1000); // Wait one second
                    }
                }
            }
        }
    }
}