Replace the below with YOUR Azure Machine LEarning Key and URL:

            const string apiKey = "ABr2vQonVvhmxC9Em0CmVLhyP8BCNijwXZTcEE+kqZckNC6nMXuz8Vu04eOoVoYfgHA9UKZK8Cp0hRTKY68b5w=="; // Replace this with the API key for the default web service
            const string endpointUrl = "https://management.azureml.net/workspaces/12e23496953e4285a7cc2d669c0cc1aa/webservices/c15dace9f8594ac5a0a76d327836ec12/endpoints/retrained";
          

            const string BaseUrl = "https://ussouthcentral.services.azureml.net/workspaces/12e23496953e4285a7cc2d669c0cc1aa/services/51664eb55e7948c2860df6e0eab25f94/jobs";

            const string StorageAccountName = "jbprinterhelpbotstorage"; // Replace this with your Azure Storage Account name
            const string StorageAccountKey = "KSIVRTFmBlnOTgvxFpjTOD6G7+/vXo0fEhG/vVHN392ShDDqoxU8aXQdWngCIn5ekoLNZpEpIo/W17LOq2s/4A=="; // Replace this with your Azure Storage Key
            const string StorageContainerName = "retrainingdatain"; // Replace this with your Azure Storage Container name

            //Update Data File below with version of training Data (1 or 2) 
            const string InputFileLocation = "C:\\JB_Azure\\Azure_Bot_ML_Best_Action\\AML_Printer_Issue_Best_Action_Data_v2_TAB.csv"; // Replace this with the location of your input file
            const string InputBlobName = "AML_Printer_Issue_Best_Action_Data.csv"; // Replace this with the name you would like to use for your Azure blob; this needs to have the same extension as the input file 

            const string apiKey = "lQChYaHanF+L8Xjf5GXLqlDnevD2bwcZA+z+KZ2bDNS4vBwgdJqdfrM5ipwL9Lv2ArZW8y4tlPkXJVB7sXi7gw=="; // Replace this with the API key for the web service
